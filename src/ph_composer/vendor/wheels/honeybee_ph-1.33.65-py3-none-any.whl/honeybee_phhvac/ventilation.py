# -*- coding: utf-8 -*-
# -*- Python Version: 2.7 -*-

"""Honeybee-PH-HVAC-Equipment: Ventilation (ERV) Devices."""

import sys
from copy import copy, deepcopy

try:
    from typing import Any, Dict, List, Optional
except ImportError:
    pass  # IronPython

try:
    from ladybug_geometry.geometry3d.pointvector import Point3D
except ImportError as e:
    raise ImportError("Failed to import ladybug_geometry", e)

try:
    from honeybee_phhvac import _base, ducting
except ImportError as e:
    raise ImportError("\nFailed to import honeybee_phhvac:\n\t{}".format(e))

try:
    from honeybee_ph_utils.validation import is_finite_real
except ImportError as e:
    raise ImportError("\nFailed to import honeybee_ph_utils:\n\t{}".format(e))


# -----------------------------------------------------------------------------


def _validated_finite_number(_value, _field_name):
    # type: (Any, str) -> Any
    """Return a finite real value or raise an error naming the physical field."""
    if not is_finite_real(_value):
        raise ValueError("{} must be a finite number; got {!r}.".format(_field_name, _value))
    return _value


def _validated_duct_collection(_ducts, _field_name, _duct_type):
    # type: (Optional[List[ducting.PhDuctElement]], str, int) -> List[ducting.PhDuctElement]
    """Return a validated duct-element list for one airflow direction."""
    if _ducts is None:
        return []

    try:
        duct_elements = list(_ducts)
    except TypeError:
        raise TypeError("{} must be an iterable of PhDuctElement objects.".format(_field_name))

    for duct_element in duct_elements:
        if not isinstance(duct_element, ducting.PhDuctElement):
            raise TypeError("{} must contain only PhDuctElement objects.".format(_field_name))
        if duct_element.duct_type != _duct_type:
            raise ValueError(
                "{} contains {!r} with duct_type={!r}; expected duct_type={}.".format(
                    _field_name,
                    duct_element.display_name,
                    duct_element.duct_type,
                    _duct_type,
                )
            )
    return duct_elements


# -----------------------------------------------------------------------------


class UnknownPhExhaustVentTypeError(Exception):
    """Raised when an unrecognized exhaust ventilation device type is encountered."""

    def __init__(self, _device_types, _received_type):
        # type: (list[str], str) -> None
        self.msg = 'Error: Unknown HBPH-Exhaust Ventilation type? Got: "{}"\
            "but only types: {} are allowed?'.format(_received_type, _device_types)
        super(UnknownPhExhaustVentTypeError, self).__init__(self.msg)


# -----------------------------------------------------------------------------
# -- ERV units


class Ventilator(_base._PhHVACBase):
    """A Passive House ventilation heat-recovery unit (ERV/HRV).

    Attributes:
        display_name (str): User-facing name for the ventilator.
        id_num (int): Numeric identifier for the ventilator.
        quantity (int): Number of identical units.
        sensible_heat_recovery (float): Sensible heat recovery efficiency (0-1).
        latent_heat_recovery (float): Latent heat recovery efficiency (0-1).
        electric_efficiency (float): Specific electric power in Wh/m3.
        frost_protection_reqd (bool): Whether frost protection is required.
        temperature_below_defrost_used (float): Temperature threshold for defrost activation (C).
        in_conditioned_space (bool): Whether the unit is located in conditioned space.
        subsoil_heat_exchange_efficiency (Optional[float]): Ground-loop effectiveness coefficient (0-1).
        preheated_intake_temperature_c (Optional[float]): Intake-air temperature after subsoil heat exchange (C).
    """

    def __init__(self):
        super(Ventilator, self).__init__()
        self.display_name = "_unnamed_ventilator_"  # type: str
        self.id_num = 0  # type: int
        self.quantity = 1  # type: int
        self.sensible_heat_recovery = 0.0  # type: float
        self.latent_heat_recovery = 0.0  # type float
        self.electric_efficiency = 0.55  # type: float
        self.frost_protection_reqd = True  # type: bool
        self.temperature_below_defrost_used = -5  # type: float
        self.in_conditioned_space = True  # type: bool
        self.subsoil_heat_exchange_efficiency = None  # type: Optional[float]
        self.preheated_intake_temperature_c = None  # type: Optional[float]

    def to_dict(self):
        # type: () -> dict[str, Any]
        d = super(Ventilator, self).to_dict()
        d["quantity"] = self.quantity
        d["sensible_heat_recovery"] = self.sensible_heat_recovery
        d["latent_heat_recovery"] = self.latent_heat_recovery
        d["electric_efficiency"] = self.electric_efficiency
        d["frost_protection_reqd"] = self.frost_protection_reqd
        d["temperature_below_defrost_used"] = self.temperature_below_defrost_used
        d["in_conditioned_space"] = self.in_conditioned_space
        if self.subsoil_heat_exchange_efficiency is not None:
            d["subsoil_heat_exchange_efficiency"] = self.subsoil_heat_exchange_efficiency
        if self.preheated_intake_temperature_c is not None:
            d["preheated_intake_temperature_c"] = self.preheated_intake_temperature_c
        return d

    @classmethod
    def from_dict(cls, _input_dict):
        # type: (dict[str, Any]) -> Ventilator
        obj = cls()
        obj.display_name = _input_dict["display_name"]
        obj.identifier = _input_dict["identifier"]
        obj.user_data = _input_dict.get("user_data", {})
        obj.quantity = _input_dict["quantity"]
        obj.sensible_heat_recovery = _input_dict["sensible_heat_recovery"]
        obj.latent_heat_recovery = _input_dict["latent_heat_recovery"]
        obj.electric_efficiency = _input_dict["electric_efficiency"]
        obj.frost_protection_reqd = _input_dict["frost_protection_reqd"]
        obj.temperature_below_defrost_used = _input_dict["temperature_below_defrost_used"]
        obj.in_conditioned_space = _input_dict["in_conditioned_space"]
        obj.subsoil_heat_exchange_efficiency = _input_dict.get("subsoil_heat_exchange_efficiency", None)
        obj.preheated_intake_temperature_c = _input_dict.get("preheated_intake_temperature_c", None)
        return obj

    def duplicate(self):
        # type: () -> Ventilator
        new_obj = Ventilator()
        new_obj.display_name = self.display_name
        new_obj.identifier = self.identifier
        new_obj.user_data = deepcopy(self.user_data)
        new_obj.id_num = self.id_num
        new_obj.quantity = self.quantity
        new_obj.sensible_heat_recovery = self.sensible_heat_recovery
        new_obj.latent_heat_recovery = self.latent_heat_recovery
        new_obj.electric_efficiency = self.electric_efficiency
        new_obj.frost_protection_reqd = self.frost_protection_reqd
        new_obj.temperature_below_defrost_used = self.temperature_below_defrost_used
        new_obj.in_conditioned_space = self.in_conditioned_space
        new_obj.subsoil_heat_exchange_efficiency = self.subsoil_heat_exchange_efficiency
        new_obj.preheated_intake_temperature_c = self.preheated_intake_temperature_c
        return new_obj

    def __lt__(self, other):
        # type: (PhVentilationSystem) -> bool
        return self.identifier < other.identifier

    def __copy__(self):
        # type: () -> Ventilator
        return self.duplicate()

    def __repr__(self):
        return "{}(display_name={!r}, sensible_heat_recovery={:0.2f})".format(
            self.__class__.__name__, self.display_name, self.sensible_heat_recovery
        )

    def ToString(self):
        return self.__repr__()


class PhVentilationSystem(_base._PhHVACBase):
    """Passive House Fresh-Air Ventilation System.

    Construct a selected balanced HRV/ERV with ``balanced_hrv()``. Represent
    no mechanical ventilation as ``None`` on the Room HVAC properties; summer
    window ACH inputs are separate and do not create this object.

    Attributes:
        display_name (str): User-facing name for the ventilation system.
        sys_type (int): System type identifier (1 = Balanced PH ventilation with HR).
        supply_ducting (List[PhDuctElement]): Supply-air duct elements.
        exhaust_ducting (List[PhDuctElement]): Exhaust-air duct elements.
        id_num (int): Numeric identifier for the system.
    """

    def __init__(self):
        # type: () -> None
        super(PhVentilationSystem, self).__init__()
        self.display_name = "_unnamed_ph_vent_system_"
        self.sys_type = 1  # '1-Balanced PH ventilation with HR'
        self.supply_ducting = []  # type: List[ducting.PhDuctElement]
        self.exhaust_ducting = []  # type: List[ducting.PhDuctElement]
        self._ventilation_unit = None  # type: Optional[Ventilator]
        self.id_num = 0

    @classmethod
    def balanced_hrv(
        cls,
        ventilator,
        supply_ducting=None,
        exhaust_ducting=None,
        display_name=None,
    ):
        # type: (Ventilator, Optional[List[ducting.PhDuctElement]], Optional[List[ducting.PhDuctElement]], Optional[str]) -> PhVentilationSystem
        """Create a balanced HRV/ERV system from selected equipment.

        The required ventilator type, recovery/electric ranges, and duct
        directions are validated; accepted children are duplicated. ``None``
        or an empty duct collection means that no exterior duct elements are
        modeled. This method never creates default ducts, chooses preliminary
        performance, or attaches the returned system to a Room.

        Arguments:
        ----------
            * ventilator (Ventilator): A selected ventilation unit with finite,
                valid recovery and electric-efficiency values.
            * supply_ducting (Optional[Iterable[PhDuctElement]]): Supply-air
                duct elements (duct_type=1). Defaults to no exterior ducts.
            * exhaust_ducting (Optional[Iterable[PhDuctElement]]): Exhaust-air
                duct elements (duct_type=2). Defaults to no exterior ducts.
            * display_name (Optional[str]): User-facing system name.

        Returns:
        --------
            * PhVentilationSystem: A new, unattached balanced system that owns
                duplicates of all supplied children.
        """
        if not isinstance(ventilator, Ventilator):
            raise TypeError("ventilator must be a Ventilator object.")

        sensible = _validated_finite_number(ventilator.sensible_heat_recovery, "sensible_heat_recovery")
        if not 0.0 < sensible <= 1.0:
            raise ValueError(
                "sensible_heat_recovery must be greater than 0 and no greater than 1; got {!r}.".format(
                    ventilator.sensible_heat_recovery
                )
            )

        latent = _validated_finite_number(ventilator.latent_heat_recovery, "latent_heat_recovery")
        if not 0.0 <= latent <= 1.0:
            raise ValueError(
                "latent_heat_recovery must be between 0 and 1 inclusive; got {!r}.".format(
                    ventilator.latent_heat_recovery
                )
            )

        electric = _validated_finite_number(ventilator.electric_efficiency, "electric_efficiency")
        if electric < 0.0:
            raise ValueError(
                "electric_efficiency must be nonnegative; got {!r}.".format(ventilator.electric_efficiency)
            )

        supply_elements = _validated_duct_collection(supply_ducting, "supply_ducting", 1)
        exhaust_elements = _validated_duct_collection(exhaust_ducting, "exhaust_ducting", 2)

        obj = cls()
        if display_name is not None:
            obj.display_name = display_name
        obj.sys_type = 1
        obj.supply_ducting = [element.duplicate() for element in supply_elements]
        obj.exhaust_ducting = [element.duplicate() for element in exhaust_elements]
        obj.ventilation_unit = ventilator.duplicate()
        return obj

    @property
    def ventilation_unit(self):
        # type: () -> Optional[Ventilator]
        """Return the Ventilator (ERV/HRV) assigned to this system."""
        return self._ventilation_unit

    @ventilation_unit.setter
    def ventilation_unit(self, _in):
        # type: (Optional[Ventilator]) -> None
        self._ventilation_unit = _in

        if not self._ventilation_unit:
            return None

        if self._ventilation_unit.display_name == "_unnamed_ventilator_":
            self._ventilation_unit.display_name = self.display_name
        return None

    def add_supply_duct_element(self, _duct_element):
        # type: (ducting.PhDuctElement) -> None
        """Add a supply-air duct element to the ventilation system.

        Arguments:
        ----------
            * _duct_element (PhDuctElement): The duct element to add.
        """
        self.supply_ducting.append(_duct_element)

    def add_exhaust_duct_element(self, _duct_element):
        # type: (ducting.PhDuctElement) -> None
        """Add an exhaust-air duct element to the ventilation system.

        Arguments:
        ----------
            * _duct_element (PhDuctElement): The duct element to add.
        """
        self.exhaust_ducting.append(_duct_element)

    @property
    def supply_ducting_total_length(self):
        # type: () -> float
        """Return the total length of all supply-air ducting in model-units."""
        return sum(duct.length for duct in self.supply_ducting)

    @property
    def exhaust_ducting_total_length(self):
        # type: () -> float
        """Return the total length of all exhaust-air ducting in model-units."""
        return sum(duct.length for duct in self.exhaust_ducting)

    @property
    def supply_ducting_size_description(self):
        # type: () -> Optional[str]
        """Return the size of the supply-air ducting."""
        descriptions = {s.shape_type_description for s in self.supply_ducting}
        if len(descriptions) == 0:
            return None
        elif len(descriptions) == 1:
            return descriptions.pop()
        else:
            raise ValueError("Mixed shape-types in supply-air duct segments.")

    @property
    def exhaust_ducting_size_description(self):
        # type: () -> Optional[str]
        """Return the size of the exhaust-air ducting."""
        descriptions = {s.shape_type_description for s in self.exhaust_ducting}
        if len(descriptions) == 0:
            return None
        elif len(descriptions) == 1:
            return descriptions.pop()
        else:
            raise ValueError("Mixed shape-types in exhaust-air duct segments.")

    def to_dict(self):
        # type: () -> dict[str, Any]
        d = super(PhVentilationSystem, self).to_dict()
        d["sys_type"] = self.sys_type
        d["exhaust_ducting"] = [e_duct.to_dict() for e_duct in self.exhaust_ducting]
        d["supply_ducting"] = [s_duct.to_dict() for s_duct in self.supply_ducting]
        d["id_num"] = self.id_num
        if self.ventilation_unit:
            d["ventilation_unit"] = self.ventilation_unit.to_dict()
        return d

    @classmethod
    def from_dict(cls, _input_dict):
        # type: (dict[str, Any]) -> PhVentilationSystem
        obj = cls()

        obj.identifier = _input_dict["identifier"]
        obj.display_name = _input_dict["display_name"]
        obj.user_data = _input_dict.get("user_data", {})
        obj.sys_type = _input_dict["sys_type"]
        obj.supply_ducting = [ducting.PhDuctElement.from_dict(s_duct) for s_duct in _input_dict["supply_ducting"]]
        obj.exhaust_ducting = [ducting.PhDuctElement.from_dict(e_duct) for e_duct in _input_dict["exhaust_ducting"]]
        obj.id_num = _input_dict.get("id_num", obj.id_num)

        vent_unit_dict = _input_dict.get("ventilation_unit", None)
        if vent_unit_dict:
            obj.ventilation_unit = Ventilator.from_dict(vent_unit_dict)

        return obj

    def _duplicate_without_ducts(self):
        # type: () -> PhVentilationSystem
        """Duplicate system metadata and equipment without copying duct collections."""
        new_obj = self.__class__()
        new_obj.display_name = self.display_name
        new_obj.identifier = self.identifier
        new_obj.user_data = deepcopy(self.user_data)
        new_obj.sys_type = self.sys_type
        new_obj.id_num = self.id_num

        if self.ventilation_unit:
            new_obj._ventilation_unit = self.ventilation_unit.duplicate()

        return new_obj

    def duplicate(self):
        # type: () -> PhVentilationSystem
        new_obj = self._duplicate_without_ducts()
        new_obj.supply_ducting = [s_duct.duplicate() for s_duct in self.supply_ducting]
        new_obj.exhaust_ducting = [e_duct.duplicate() for e_duct in self.exhaust_ducting]
        return new_obj

    def __copy__(self):
        # type: () -> PhVentilationSystem
        return self.duplicate()

    def __lt__(self, other):
        # type: (PhVentilationSystem) -> bool
        return self.identifier < other.identifier

    def __repr__(self):
        return "{}(display_name={!r}, sys_type={!r})".format(self.__class__.__name__, self.display_name, self.sys_type)

    def ToString(self):
        return self.__repr__()

    def move(self, moving_vec3D):
        """Move the System's ducts along a vector.

        Arguments:
        ----------
            * moving_vec3D (Vector3D): A Vector3D with the direction and distance to move the ray.

        Returns:
        --------
            * PhVentilationSystem: A new system with moved ducts.
        """
        new_system = self._duplicate_without_ducts()
        new_system.supply_ducting = [duct_element.move(moving_vec3D) for duct_element in self.supply_ducting]
        new_system.exhaust_ducting = [duct_element.move(moving_vec3D) for duct_element in self.exhaust_ducting]
        return new_system

    def rotate(self, axis_vec3D, angle_degrees, origin_pt3D):
        """Rotate the System's ducts by a certain angle around an axis and origin.

        Right hand rule applies:
        If axis has a positive orientation, rotation will be clockwise.
        If axis has a negative orientation, rotation will be counterclockwise.

        Arguments:
        ----------
            * axis_vec3D (Vector3D): A Vector3D axis representing the axis of rotation.
            * angle_degrees (float): An angle for rotation in degrees.
            * origin_pt3D (Point3D): A Point3D for the origin around which the object will be rotated.

        Returns:
        --------
            * PhVentilationSystem: A new system with rotated ducts.
        """
        new_system = self._duplicate_without_ducts()
        new_system.supply_ducting = [
            duct_element.rotate(axis_vec3D, angle_degrees, origin_pt3D) for duct_element in self.supply_ducting
        ]
        new_system.exhaust_ducting = [
            duct_element.rotate(axis_vec3D, angle_degrees, origin_pt3D) for duct_element in self.exhaust_ducting
        ]
        return new_system

    def rotate_xy(self, angle_degrees, origin_pt3D):
        """Rotate the System's ducts counterclockwise in the XY plane by a certain angle.

        Arguments:
        ----------
            * angle_degrees (float): An angle in degrees.
            * origin_pt3D (Point3D): A Point3D for the origin around which the object will be rotated.

        Returns:
        --------
            * PhVentilationSystem: A new system with rotated ducts.
        """
        new_system = self._duplicate_without_ducts()
        new_system.supply_ducting = [
            duct_element.rotate_xy(angle_degrees, origin_pt3D) for duct_element in self.supply_ducting
        ]
        new_system.exhaust_ducting = [
            duct_element.rotate_xy(angle_degrees, origin_pt3D) for duct_element in self.exhaust_ducting
        ]
        return new_system

    def reflect(self, normal_vec3D, origin_pt3D):
        """Reflect the System's ducts across a plane with the input normal vector and origin.

        Arguments:
        ----------
            * normal_vec3D (Vector3D): A normalized Vector3D representing the plane normal.
            * origin_pt3D (Point3D): A Point3D representing the origin from which to reflect.

        Returns:
        --------
            * PhVentilationSystem: A new system with reflected ducts.
        """
        new_system = self._duplicate_without_ducts()
        new_system.supply_ducting = [
            duct_element.reflect(normal_vec3D, origin_pt3D) for duct_element in self.supply_ducting
        ]
        new_system.exhaust_ducting = [
            duct_element.reflect(normal_vec3D, origin_pt3D) for duct_element in self.exhaust_ducting
        ]
        return new_system

    def scale(self, scale_factor, origin_pt3D=None):
        # type: (float, Optional[Point3D]) -> PhVentilationSystem
        """Scale the System's ducts by a factor from an origin point.

        Arguments:
        ----------
            * scale_factor (float): A number representing how much the ducts should be scaled.
            * origin_pt3D (Optional[Point3D]): A Point3D representing the origin from which to scale.
                If None, it will be scaled from the World origin (0, 0, 0).

        Returns:
        --------
            * PhVentilationSystem: A new system with scaled ducts.
        """
        new_system = self._duplicate_without_ducts()
        new_system.supply_ducting = [
            duct_element.scale(scale_factor, origin_pt3D) for duct_element in self.supply_ducting
        ]
        new_system.exhaust_ducting = [
            duct_element.scale(scale_factor, origin_pt3D) for duct_element in self.exhaust_ducting
        ]
        return new_system


# -----------------------------------------------------------------------------
# -- Exhaust Ventilators are not part of the Ventilation System,
# -- but instead are treated more like appliances which get added to the Room.


class _ExhaustVentilatorBase(_base._PhHVACBase):
    def __init__(self):
        super(_ExhaustVentilatorBase, self).__init__()
        self.device_class_name = self.__class__.__name__
        self.display_name = "_unnamed_exhaust_ventilator_"
        self.quantity = 1
        self.annual_runtime_minutes = 0.0
        self.exhaust_flow_rate_m3s = 0.0

    def to_dict(self):
        # type: () -> Dict[str, Any]
        d = super(_ExhaustVentilatorBase, self).to_dict()
        d["device_class_name"] = self.device_class_name
        d["quantity"] = self.quantity
        d["annual_runtime_minutes"] = self.annual_runtime_minutes
        d["exhaust_flow_rate_m3s"] = self.exhaust_flow_rate_m3s
        return d

    @classmethod
    def from_dict(cls, _input_dict):
        # type: (Dict[str, Any]) -> _ExhaustVentilatorBase
        new_obj = cls()
        new_obj.display_name = _input_dict["display_name"]
        new_obj.identifier = _input_dict["identifier"]
        new_obj.user_data = _input_dict.get("user_data", {})
        new_obj.device_class_name = _input_dict["device_class_name"]
        new_obj.quantity = _input_dict["quantity"]
        new_obj.annual_runtime_minutes = _input_dict["annual_runtime_minutes"]
        new_obj.exhaust_flow_rate_m3s = _input_dict["exhaust_flow_rate_m3s"]
        return new_obj

    def __lt__(self, other):
        # type: (_ExhaustVentilatorBase) -> bool
        return self.identifier < other.identifier

    def __str__(self):
        return "{}(display_name={!r}, exhaust_flow_rate_m3s={:0.02f})".format(
            self.__class__.__name__, self.display_name, self.exhaust_flow_rate_m3s
        )

    def __repr__(self):
        return str(self)

    def ToString(self):
        return self.__repr__()

    def move(self, moving_vec3D):
        """Move the device's elements along a vector.

        Arguments:
        ----------
            * moving_vec3D (Vector3D): A Vector3D with the direction and distance to move.
        """
        pass

    def rotate(self, axis_vec3D, angle_degrees, origin_pt3D):
        """Rotate the device's elements by a certain angle around an axis and origin.

        Right hand rule applies:
        If axis has a positive orientation, rotation will be clockwise.
        If axis has a negative orientation, rotation will be counterclockwise.

        Arguments:
        ----------
            * axis_vec3D (Vector3D): A Vector3D representing the axis of rotation.
            * angle_degrees (float): An angle for rotation in degrees.
            * origin_pt3D (Point3D): A Point3D for the origin around which the object will be rotated.
        """
        pass

    def rotate_xy(self, angle_degrees, origin_pt3D):
        """Rotate the device's elements counterclockwise in the XY plane by a certain angle.

        Arguments:
        ----------
            * angle_degrees (float): An angle in degrees.
            * origin_pt3D (Point3D): A Point3D for the origin around which the object will be rotated.
        """
        pass

    def reflect(self, normal_vec3D, origin_pt3D):
        """Reflect the device's elements across a plane with the input normal vector and origin.

        Arguments:
        ----------
            * normal_vec3D (Vector3D): A normalized Vector3D representing the plane normal.
            * origin_pt3D (Point3D): A Point3D representing the origin from which to reflect.
        """
        pass

    def scale(self, scale_factor, origin_pt3D=None):
        """Scale the device's elements by a factor from an origin point.

        Arguments:
        ----------
            * scale_factor (float): A number representing how much the device should be scaled.
            * origin_pt3D (Optional[Point3D]): A Point3D representing the origin from which to scale.
                If None, it will be scaled from the World origin (0, 0, 0).
        """
        pass

    def __copy__(self):
        # type: () -> ExhaustVentDryer
        raise NotImplementedError("This method must be implemented by the subclass.")

    def duplicate(self):
        # type: () -> ExhaustVentDryer
        raise NotImplementedError("This method must be implemented by the subclass.")


class ExhaustVentDryer(_ExhaustVentilatorBase):
    """Exhaust ventilation device representing a clothes dryer."""

    def __init__(self):
        super(ExhaustVentDryer, self).__init__()
        self.display_name = "_unnamed_dryer_exh_"

    def __copy__(self):
        # type: () -> ExhaustVentDryer
        return self.duplicate()

    def duplicate(self):
        # type: () -> ExhaustVentDryer
        new_obj = self.__class__()
        new_obj.identifier = self.identifier
        new_obj.display_name = self.display_name
        new_obj.user_data = copy(self.user_data)
        new_obj.quantity = self.quantity
        new_obj.annual_runtime_minutes = self.annual_runtime_minutes
        new_obj.device_class_name = self.device_class_name
        new_obj.exhaust_flow_rate_m3s = self.exhaust_flow_rate_m3s
        return new_obj


class ExhaustVentKitchenHood(_ExhaustVentilatorBase):
    """Exhaust ventilation device representing a kitchen range hood."""

    def __init__(self):
        super(ExhaustVentKitchenHood, self).__init__()
        self.display_name = "_unnamed_kitchen_hood_exh_"

    def __copy__(self):
        # type: () -> ExhaustVentKitchenHood
        return self.duplicate()

    def duplicate(self):
        # type: () -> ExhaustVentKitchenHood
        new_obj = self.__class__()
        new_obj.identifier = self.identifier
        new_obj.display_name = self.display_name
        new_obj.user_data = copy(self.user_data)
        new_obj.quantity = self.quantity
        new_obj.annual_runtime_minutes = self.annual_runtime_minutes
        new_obj.device_class_name = self.device_class_name
        new_obj.exhaust_flow_rate_m3s = self.exhaust_flow_rate_m3s
        return new_obj


class ExhaustVentUserDefined(_ExhaustVentilatorBase):
    """Exhaust ventilation device with user-defined parameters."""

    def __init__(self):
        super(ExhaustVentUserDefined, self).__init__()
        self.display_name = "_unnamed_user_defined_exh_"

    def __copy__(self):
        # type: () -> ExhaustVentUserDefined
        return self.duplicate()

    def duplicate(self):
        # type: () -> ExhaustVentUserDefined
        new_obj = self.__class__()
        new_obj.identifier = self.identifier
        new_obj.display_name = self.display_name
        new_obj.user_data = copy(self.user_data)
        new_obj.quantity = self.quantity
        new_obj.annual_runtime_minutes = self.annual_runtime_minutes
        new_obj.device_class_name = self.device_class_name
        new_obj.exhaust_flow_rate_m3s = self.exhaust_flow_rate_m3s
        return new_obj


class PhExhaustDeviceBuilder(object):
    """Constructor class for HBPH-Exhaust Ventilation Devices"""

    @classmethod
    def from_dict(cls, _input_dict):
        # type: (dict[str, Any]) -> _ExhaustVentilatorBase
        """Find the right device constructor class from the module based on the 'type' name."""
        device_class_name = _input_dict["device_class_name"]  # type: str

        valid_class_types = [nm for nm in dir(sys.modules[__name__]) if nm.startswith("ExhaustVent")]

        if device_class_name not in valid_class_types:
            raise UnknownPhExhaustVentTypeError(valid_class_types, device_class_name)
        device_class = getattr(sys.modules[__name__], device_class_name)  # type: _ExhaustVentilatorBase
        new_equipment = device_class.from_dict(_input_dict)
        return new_equipment

    def __str__(self):
        return "{}()".format(self.__class__.__name__)

    def __repr__(self):
        return str(self)

    def ToString(self):
        """Overwrite .NET ToString."""
        return repr(self)
