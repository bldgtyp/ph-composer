# -*- coding: utf-8 -*-
# -*- Python Version: 2.7 -*-

"""PH Foundation Objects."""

from copy import copy

try:
    from typing import Any, Dict, List, Union
except ImportError:
    pass  # Python2.7

try:
    from honeybee_ph import _base
except ImportError as e:
    raise ImportError("\nFailed to import honeybee_ph:\n\t{}".format(e))

try:
    from honeybee_ph_utils import enumerables
except ImportError as e:
    raise ImportError("\nFailed to import honeybee_ph_utils:\n\t{}".format(e))


# -----------------------------------------------------------------------------


class PhFoundationType(enumerables.CustomEnum):
    """Classification of foundation types for PH certification.

    Values:
        1-HEATED_BASEMENT: Fully conditioned basement.
        2-UNHEATED_BASEMENT: Unconditioned basement below thermal envelope.
        3-SLAB_ON_GRADE: Foundation slab directly on soil.
        4-VENTED_CRAWLSPACE: Ventilated crawlspace below floor.
        5-NONE: No foundation modeled.
    """

    allowed = [
        "1-HEATED_BASEMENT",
        "2-UNHEATED_BASEMENT",
        "3-SLAB_ON_GRADE",
        "4-VENTED_CRAWLSPACE",
        "5-NONE",
    ]

    def __init__(self, _value=1):
        # type: (Union[str, int]) -> None
        super(PhFoundationType, self).__init__(_value)


class PhSlabEdgeInsulationPosition(enumerables.CustomEnum):
    """Position of perimeter slab edge insulation.

    Values:
        1-UNDEFINED: Undefined or not specified.
        2-HORIZONTAL: Horizontal insulation extending outward from slab edge.
        3-VERTICAL: Vertical insulation extending downward from slab edge.
    """

    allowed = [
        "1-UNDEFINED",
        "2-HORIZONTAL",
        "3-VERTICAL",
    ]

    def __init__(self, _value=1):
        # type: (Union[str, int]) -> None
        super(PhSlabEdgeInsulationPosition, self).__init__(_value)


# -----------------------------------------------------------------------------
# -- Base Class


class PhFoundation(_base._Base):
    """Base class for all PH foundation types.

    Subclassed by specific foundation geometries (heated basement, slab-on-grade,
    etc.). Use PhFoundationFactory to instantiate the correct subclass from a dict.

    Attributes:
        foundation_type (PhFoundationType): The foundation classification.
            Default: "5-NONE".
    """

    def __init__(self):
        super(PhFoundation, self).__init__()
        self.foundation_type = PhFoundationType("5-NONE")

    def duplicate(self):
        # type: () -> PhFoundation
        return self.__copy__()

    def __copy__(self):
        new_obj = self.__class__()
        new_obj.display_name = self.display_name
        new_obj.identifier = self.identifier
        new_obj.user_data = self.user_data
        new_obj.foundation_type = PhFoundationType(self.foundation_type.value)
        new_obj.user_data = self.user_data
        return new_obj

    def to_dict(self):
        # type: () -> Dict[str, Any]
        d = {}

        d["identifier"] = str(self.identifier)
        d["display_name"] = self.display_name
        d["user_data"] = copy(self.user_data)
        d["foundation_type_value"] = self.foundation_type.value
        d["user_data"] = copy(self.user_data)

        return d

    @classmethod
    def from_dict(cls, _input_dict):
        # type: (Dict[str, Any]) -> PhFoundation
        new_obj = cls()

        new_obj.identifier = _input_dict["identifier"]
        new_obj.display_name = _input_dict["display_name"]
        new_obj.user_data = _input_dict.get("user_data", {})
        new_obj.foundation_type = PhFoundationType(_input_dict["foundation_type_value"])
        new_obj.user_data = _input_dict.get("user_data", {})

        return new_obj

    def base_attrs_from_dict(self, _obj, _input_dict):
        # type: (PhFoundation, dict) -> None
        """Set the base object attributes from a dictionary

        Arguments:
        ----------
            * _obj (PhFoundation): The PH Foundation object to set the attributes of.
            * _input_dict (dict): The dictionary to get the attribute values from.

        Returns:
        --------
            * None
        """
        for attr_name in vars(self).keys():
            try:
                # Strip off underscore so it uses the property setters
                if attr_name.startswith("_"):
                    attr_name = attr_name[1:]
                setattr(_obj, attr_name, _input_dict[attr_name])
            except KeyError:
                pass
        return None

    def __str__(self):
        return "{}(display_name: {}, type: {})".format(
            self.__class__.__name__, self.display_name, self.foundation_type.value
        )

    def __repr__(self):
        return str(self)

    def ToString(self):
        return str(self)


# -----------------------------------------------------------------------------
# -- Specific Foundation Types


class PhHeatedBasement(PhFoundation):
    """Heated (conditioned) basement foundation.

    Attributes:
        floor_slab_area_m2 (float): Floor slab area in square meters.
        floor_slab_u_value (float): Floor slab U-value in W/(m2K). Default: 1.0.
        floor_slab_exposed_perimeter_m (float): Exposed perimeter length in meters.
        slab_depth_below_grade_m (float): Depth of slab below grade in meters.
            Default: 2.5.
        basement_wall_u_value (float): Basement wall U-value in W/(m2K).
            Default: 1.0.
    """

    def __init__(self):
        super(PhHeatedBasement, self).__init__()
        self.foundation_type = PhFoundationType("1-HEATED_BASEMENT")
        self.floor_slab_area_m2 = 0.0
        self.floor_slab_u_value = 1.0
        self.floor_slab_exposed_perimeter_m = 0.0
        self.slab_depth_below_grade_m = 2.5
        self.basement_wall_u_value = 1.0

    def __copy__(self):
        # type: () -> PhHeatedBasement
        obj = self.__class__()
        obj.display_name = self.display_name
        obj.identifier = self.identifier
        obj.user_data = self.user_data
        obj.foundation_type = self.foundation_type
        obj.floor_slab_area_m2 = self.floor_slab_area_m2
        obj.floor_slab_u_value = self.floor_slab_u_value
        obj.floor_slab_exposed_perimeter_m = self.floor_slab_exposed_perimeter_m
        obj.slab_depth_below_grade_m = self.slab_depth_below_grade_m
        obj.basement_wall_u_value = self.basement_wall_u_value
        return obj

    def duplicate(self):
        # type: () -> PhHeatedBasement
        return self.__copy__()

    def to_dict(self):
        # type: () -> Dict[str, Any]
        d = {}
        d.update(super(PhHeatedBasement, self).to_dict())
        d["floor_slab_area_m2"] = self.floor_slab_area_m2
        d["floor_slab_u_value"] = self.floor_slab_u_value
        d["floor_slab_exposed_perimeter_m"] = self.floor_slab_exposed_perimeter_m
        d["slab_depth_below_grade_m"] = self.slab_depth_below_grade_m
        d["basement_wall_u_value"] = self.basement_wall_u_value
        return d

    @classmethod
    def from_dict(cls, _input_dict):
        # type: (Dict[str, Any]) -> PhHeatedBasement
        new_obj = cls()
        super(PhHeatedBasement, new_obj).base_attrs_from_dict(new_obj, _input_dict)
        new_obj.floor_slab_area_m2 = _input_dict["floor_slab_area_m2"]
        new_obj.floor_slab_u_value = _input_dict["floor_slab_u_value"]
        new_obj.floor_slab_exposed_perimeter_m = _input_dict["floor_slab_exposed_perimeter_m"]
        new_obj.slab_depth_below_grade_m = _input_dict["slab_depth_below_grade_m"]
        new_obj.basement_wall_u_value = _input_dict["basement_wall_u_value"]
        return new_obj


class PhUnheatedBasement(PhFoundation):
    """Unheated (unconditioned) basement foundation.

    Attributes:
        floor_ceiling_area_m2 (float): Area of ceiling above the basement in m2.
        ceiling_u_value (float): Ceiling U-value in W/(m2K). Default: 1.0.
        floor_slab_exposed_perimeter_m (float): Exposed perimeter length in meters.
        slab_depth_below_grade_m (float): Depth of slab below grade in meters.
        basement_wall_height_above_grade_m (float): Wall height above grade in meters.
        basement_wall_uValue_below_grade (float): Below-grade wall U-value in W/(m2K).
            Default: 1.0.
        basement_wall_uValue_above_grade (float): Above-grade wall U-value in W/(m2K).
            Default: 1.0.
        floor_slab_u_value (float): Floor slab U-value in W/(m2K). Default: 1.0.
        basement_volume_m3 (float): Basement air volume in cubic meters.
        basement_ventilation_ach (float): Basement ventilation rate in ACH.
        interior_wall_to_heated_area_m2 (float): Area of the interior wall
            towards the heated part of the building in m2. PHPP 10 only
            (Ground!H36). Default: 0.0.
        interior_wall_to_heated_u_value (float): U-value of that interior wall
            in W/(m2K). PHPP 10 only (Ground!P36). Default: 0.0.
    """

    def __init__(self):
        super(PhUnheatedBasement, self).__init__()
        self.foundation_type = PhFoundationType("2-UNHEATED_BASEMENT")
        self.floor_ceiling_area_m2 = 0.0
        self.ceiling_u_value = 1.0
        self.floor_slab_exposed_perimeter_m = 0.0
        self.slab_depth_below_grade_m = 0.0
        self.basement_wall_height_above_grade_m = 0.0
        self.basement_wall_uValue_below_grade = 1.0
        self.basement_wall_uValue_above_grade = 1.0
        self.floor_slab_u_value = 1.0
        self.basement_volume_m3 = 0.0
        self.basement_ventilation_ach = 0.0
        self.interior_wall_to_heated_area_m2 = 0.0
        self.interior_wall_to_heated_u_value = 0.0

    def __copy__(self):
        # type: () -> PhUnheatedBasement
        obj = self.__class__()
        obj.display_name = self.display_name
        obj.identifier = self.identifier
        obj.user_data = self.user_data
        obj.foundation_type = self.foundation_type
        obj.floor_ceiling_area_m2 = self.floor_ceiling_area_m2
        obj.ceiling_u_value = self.ceiling_u_value
        obj.floor_slab_exposed_perimeter_m = self.floor_slab_exposed_perimeter_m
        obj.slab_depth_below_grade_m = self.slab_depth_below_grade_m
        obj.basement_wall_height_above_grade_m = self.basement_wall_height_above_grade_m
        obj.basement_wall_uValue_below_grade = self.basement_wall_uValue_below_grade
        obj.basement_wall_uValue_above_grade = self.basement_wall_uValue_above_grade
        obj.floor_slab_u_value = self.floor_slab_u_value
        obj.basement_volume_m3 = self.basement_volume_m3
        obj.basement_ventilation_ach = self.basement_ventilation_ach
        obj.interior_wall_to_heated_area_m2 = self.interior_wall_to_heated_area_m2
        obj.interior_wall_to_heated_u_value = self.interior_wall_to_heated_u_value
        return obj

    def duplicate(self):
        # type: () -> PhUnheatedBasement
        return self.__copy__()

    def to_dict(self):
        # type: () -> Dict[str, Any]
        d = {}
        d.update(super(PhUnheatedBasement, self).to_dict())
        d["floor_ceiling_area_m2"] = self.floor_ceiling_area_m2
        d["ceiling_u_value"] = self.ceiling_u_value
        d["floor_slab_exposed_perimeter_m"] = self.floor_slab_exposed_perimeter_m
        d["slab_depth_below_grade_m"] = self.slab_depth_below_grade_m
        d["basement_wall_height_above_grade_m"] = self.basement_wall_height_above_grade_m
        d["basement_wall_uValue_below_grade"] = self.basement_wall_uValue_below_grade
        d["basement_wall_uValue_above_grade"] = self.basement_wall_uValue_above_grade
        d["floor_slab_u_value"] = self.floor_slab_u_value
        d["basement_volume_m3"] = self.basement_volume_m3
        d["basement_ventilation_ach"] = self.basement_ventilation_ach
        d["interior_wall_to_heated_area_m2"] = self.interior_wall_to_heated_area_m2
        d["interior_wall_to_heated_u_value"] = self.interior_wall_to_heated_u_value
        return d

    @classmethod
    def from_dict(cls, _input_dict):
        # type: (Dict[str, Any]) -> PhUnheatedBasement
        new_obj = cls()
        super(PhUnheatedBasement, new_obj).base_attrs_from_dict(new_obj, _input_dict)
        new_obj.floor_ceiling_area_m2 = _input_dict["floor_ceiling_area_m2"]
        new_obj.ceiling_u_value = _input_dict["ceiling_u_value"]
        new_obj.floor_slab_exposed_perimeter_m = _input_dict["floor_slab_exposed_perimeter_m"]
        new_obj.slab_depth_below_grade_m = _input_dict["slab_depth_below_grade_m"]
        new_obj.basement_wall_height_above_grade_m = _input_dict["basement_wall_height_above_grade_m"]
        new_obj.basement_wall_uValue_below_grade = _input_dict["basement_wall_uValue_below_grade"]
        new_obj.basement_wall_uValue_above_grade = _input_dict["basement_wall_uValue_above_grade"]
        new_obj.floor_slab_u_value = _input_dict["floor_slab_u_value"]
        new_obj.basement_volume_m3 = _input_dict["basement_volume_m3"]
        new_obj.basement_ventilation_ach = _input_dict["basement_ventilation_ach"]
        # -- Added after the class shipped, so absent from older HBJSON.
        new_obj.interior_wall_to_heated_area_m2 = _input_dict.get("interior_wall_to_heated_area_m2", 0.0)
        new_obj.interior_wall_to_heated_u_value = _input_dict.get("interior_wall_to_heated_u_value", 0.0)
        return new_obj


class PhSlabOnGrade(PhFoundation):
    """Slab-on-grade foundation.

    Attributes:
        floor_slab_area_m2 (float): Floor slab area in square meters.
        floor_slab_u_value (Optional[float]): Floor slab U-value in W/(m2K).
            None if not set.
        floor_slab_exposed_perimeter_m (float): Exposed perimeter length in meters.
        perim_insulation_width_or_depth_m (float): Insulation width or depth in
            meters. Default: 0.0 (no perimeter insulation, matching PHPP).
        perim_insulation_thickness_m (float): Insulation thickness in meters.
            Default: 0.0 (no perimeter insulation, matching PHPP).
        perim_insulation_conductivity (float): Insulation thermal conductivity
            in W/(mK). Default: 0.0 (no perimeter insulation, matching PHPP).
        interior_wall_to_heated_area_m2 (float): Area of the interior wall
            towards the heated part of the building in m2. PHPP 10 only
            (Ground!H28). Default: 0.0.
        interior_wall_to_heated_u_value (float): U-value of that interior wall
            in W/(m2K). PHPP 10 only (Ground!P28). Default: 0.0.
    """

    def __init__(self):
        super(PhSlabOnGrade, self).__init__()
        self.foundation_type = PhFoundationType("3-SLAB_ON_GRADE")
        self.floor_slab_area_m2 = 0.0
        self.floor_slab_u_value = None  # type: Union[float, None]
        self.floor_slab_exposed_perimeter_m = 0.0
        self._perim_insulation_position = PhSlabEdgeInsulationPosition("3-VERTICAL")
        self.perim_insulation_width_or_depth_m = 0.0
        self.perim_insulation_thickness_m = 0.0
        self.perim_insulation_conductivity = 0.0
        self.interior_wall_to_heated_area_m2 = 0.0
        self.interior_wall_to_heated_u_value = 0.0

    @property
    def perim_insulation_position(self):
        # type: () -> PhSlabEdgeInsulationPosition
        """The perimeter insulation position (horizontal or vertical)."""
        return self._perim_insulation_position

    @perim_insulation_position.setter
    def perim_insulation_position(self, _input):
        self._perim_insulation_position = PhSlabEdgeInsulationPosition(_input)

    def __copy__(self):
        # type: () -> PhSlabOnGrade
        obj = self.__class__()
        obj.display_name = self.display_name
        obj.identifier = self.identifier
        obj.user_data = self.user_data
        obj.foundation_type = self.foundation_type
        obj.floor_slab_area_m2 = self.floor_slab_area_m2
        obj.floor_slab_u_value = self.floor_slab_u_value
        obj.floor_slab_exposed_perimeter_m = self.floor_slab_exposed_perimeter_m
        obj._perim_insulation_position = self._perim_insulation_position
        obj.perim_insulation_width_or_depth_m = self.perim_insulation_width_or_depth_m
        obj.perim_insulation_thickness_m = self.perim_insulation_thickness_m
        obj.perim_insulation_conductivity = self.perim_insulation_conductivity
        obj.interior_wall_to_heated_area_m2 = self.interior_wall_to_heated_area_m2
        obj.interior_wall_to_heated_u_value = self.interior_wall_to_heated_u_value
        return obj

    def duplicate(self):
        # type: () -> PhSlabOnGrade
        return self.__copy__()

    def to_dict(self):
        # type: () -> Dict[str, Any]
        d = {}
        d.update(super(PhSlabOnGrade, self).to_dict())
        d["floor_slab_area_m2"] = self.floor_slab_area_m2
        d["floor_slab_u_value"] = self.floor_slab_u_value
        d["floor_slab_exposed_perimeter_m"] = self.floor_slab_exposed_perimeter_m
        d["perim_insulation_position_value"] = self.perim_insulation_position.value
        d["perim_insulation_width_or_depth_m"] = self.perim_insulation_width_or_depth_m
        d["perim_insulation_thickness_m"] = self.perim_insulation_thickness_m
        d["perim_insulation_conductivity"] = self.perim_insulation_conductivity
        d["interior_wall_to_heated_area_m2"] = self.interior_wall_to_heated_area_m2
        d["interior_wall_to_heated_u_value"] = self.interior_wall_to_heated_u_value
        return d

    @classmethod
    def from_dict(cls, _input_dict):
        # type: (Dict[str, Any]) -> PhSlabOnGrade
        new_obj = cls()
        super(PhSlabOnGrade, new_obj).base_attrs_from_dict(new_obj, _input_dict)
        new_obj.floor_slab_area_m2 = _input_dict["floor_slab_area_m2"]
        new_obj.floor_slab_u_value = _input_dict["floor_slab_u_value"]
        new_obj.floor_slab_exposed_perimeter_m = _input_dict["floor_slab_exposed_perimeter_m"]
        new_obj.perim_insulation_position = _input_dict["perim_insulation_position_value"]
        new_obj.perim_insulation_width_or_depth_m = _input_dict["perim_insulation_width_or_depth_m"]
        new_obj.perim_insulation_thickness_m = _input_dict["perim_insulation_thickness_m"]
        new_obj.perim_insulation_conductivity = _input_dict["perim_insulation_conductivity"]
        # -- Added after the class shipped, so absent from older HBJSON.
        new_obj.interior_wall_to_heated_area_m2 = _input_dict.get("interior_wall_to_heated_area_m2", 0.0)
        new_obj.interior_wall_to_heated_u_value = _input_dict.get("interior_wall_to_heated_u_value", 0.0)
        return new_obj


class PhVentedCrawlspace(PhFoundation):
    """Ventilated crawlspace foundation.

    Attributes:
        crawlspace_floor_slab_area_m2 (float): Crawlspace floor slab area in m2.
        ceiling_above_crawlspace_u_value (float): Ceiling U-value above
            crawlspace in W/(m2K). Default: 1.0.
        crawlspace_floor_exposed_perimeter_m (float): Exposed perimeter in meters.
            Default: 0.0.
        crawlspace_wall_height_above_grade_m (float): Crawlspace wall height
            above grade in meters.
        crawlspace_floor_u_value (float): Crawlspace floor U-value in W/(m2K).
            Default: 1.0.
        crawlspace_vent_opening_are_m2 (float): Ventilation opening area in m2.
        crawlspace_wall_u_value (float): Crawlspace wall U-value in W/(m2K).
            Default: 1.0.
        wind_velocity_at_10m_m_s (float): Average site wind velocity at 10m
            height in m/s (Ground!P42). Default: 4.0, the PHPP value.
        wind_shield_factor (float): Wind-shield factor for the crawlspace
            ventilation openings (Ground!P43). A free float, not an enum:
            PHPP accepts any number. [[P17]] Table 12 gives guideline values
            for protected, average and exposed sites. Default: 0.05, the
            PHPP value.
        interior_wall_to_heated_area_m2 (float): Area of the interior wall
            towards the heated part of the building in m2. PHPP 10 only
            (Ground!H44). Default: 0.0.
        interior_wall_to_heated_u_value (float): U-value of that interior wall
            in W/(m2K). PHPP 10 only (Ground!P44). Default: 0.0.
    """

    def __init__(self):
        super(PhVentedCrawlspace, self).__init__()
        self.foundation_type = PhFoundationType("4-VENTED_CRAWLSPACE")
        self.crawlspace_floor_slab_area_m2 = 0.0
        self.ceiling_above_crawlspace_u_value = 1.0
        self.crawlspace_floor_exposed_perimeter_m = 0.0
        self.crawlspace_wall_height_above_grade_m = 0.0
        self.crawlspace_floor_u_value = 1.0
        self.crawlspace_vent_opening_are_m2 = 0.0
        self.crawlspace_wall_u_value = 1.0
        self.wind_velocity_at_10m_m_s = 4.0
        self.wind_shield_factor = 0.05
        self.interior_wall_to_heated_area_m2 = 0.0
        self.interior_wall_to_heated_u_value = 0.0

    def __copy__(self):
        # type: () -> PhVentedCrawlspace
        obj = self.__class__()
        obj.display_name = self.display_name
        obj.identifier = self.identifier
        obj.user_data = self.user_data
        obj.foundation_type = self.foundation_type
        obj.crawlspace_floor_slab_area_m2 = self.crawlspace_floor_slab_area_m2
        obj.ceiling_above_crawlspace_u_value = self.ceiling_above_crawlspace_u_value
        obj.crawlspace_floor_exposed_perimeter_m = self.crawlspace_floor_exposed_perimeter_m
        obj.crawlspace_wall_height_above_grade_m = self.crawlspace_wall_height_above_grade_m
        obj.crawlspace_floor_u_value = self.crawlspace_floor_u_value
        obj.crawlspace_vent_opening_are_m2 = self.crawlspace_vent_opening_are_m2
        obj.crawlspace_wall_u_value = self.crawlspace_wall_u_value
        obj.wind_velocity_at_10m_m_s = self.wind_velocity_at_10m_m_s
        obj.wind_shield_factor = self.wind_shield_factor
        obj.interior_wall_to_heated_area_m2 = self.interior_wall_to_heated_area_m2
        obj.interior_wall_to_heated_u_value = self.interior_wall_to_heated_u_value
        return obj

    def duplicate(self):
        # type: () -> PhVentedCrawlspace
        return self.__copy__()

    def to_dict(self):
        # type: () -> Dict[str, Any]
        d = {}
        d.update(super(PhVentedCrawlspace, self).to_dict())
        d["crawlspace_floor_slab_area_m2"] = self.crawlspace_floor_slab_area_m2
        d["ceiling_above_crawlspace_u_value"] = self.ceiling_above_crawlspace_u_value
        d["crawlspace_floor_exposed_perimeter_m"] = self.crawlspace_floor_exposed_perimeter_m
        d["crawlspace_wall_height_above_grade_m"] = self.crawlspace_wall_height_above_grade_m
        d["crawlspace_floor_u_value"] = self.crawlspace_floor_u_value
        d["crawlspace_vent_opening_are_m2"] = self.crawlspace_vent_opening_are_m2
        d["crawlspace_wall_u_value"] = self.crawlspace_wall_u_value
        d["wind_velocity_at_10m_m_s"] = self.wind_velocity_at_10m_m_s
        d["wind_shield_factor"] = self.wind_shield_factor
        d["interior_wall_to_heated_area_m2"] = self.interior_wall_to_heated_area_m2
        d["interior_wall_to_heated_u_value"] = self.interior_wall_to_heated_u_value
        return d

    @classmethod
    def from_dict(cls, _input_dict):
        # type: (Dict[str, Any]) -> PhVentedCrawlspace
        new_obj = cls()
        super(PhVentedCrawlspace, new_obj).base_attrs_from_dict(new_obj, _input_dict)
        new_obj.crawlspace_floor_slab_area_m2 = _input_dict["crawlspace_floor_slab_area_m2"]
        new_obj.ceiling_above_crawlspace_u_value = _input_dict["ceiling_above_crawlspace_u_value"]
        new_obj.crawlspace_floor_exposed_perimeter_m = _input_dict["crawlspace_floor_exposed_perimeter_m"]
        new_obj.crawlspace_wall_height_above_grade_m = _input_dict["crawlspace_wall_height_above_grade_m"]
        new_obj.crawlspace_floor_u_value = _input_dict["crawlspace_floor_u_value"]
        new_obj.crawlspace_vent_opening_are_m2 = _input_dict["crawlspace_vent_opening_are_m2"]
        new_obj.crawlspace_wall_u_value = _input_dict["crawlspace_wall_u_value"]
        # -- Added after the class shipped, so absent from older HBJSON.
        new_obj.wind_velocity_at_10m_m_s = _input_dict.get("wind_velocity_at_10m_m_s", 4.0)
        new_obj.wind_shield_factor = _input_dict.get("wind_shield_factor", 0.05)
        new_obj.interior_wall_to_heated_area_m2 = _input_dict.get("interior_wall_to_heated_area_m2", 0.0)
        new_obj.interior_wall_to_heated_u_value = _input_dict.get("interior_wall_to_heated_u_value", 0.0)
        return new_obj


# -----------------------------------------------------------------------------
# --- Factory


class PhFoundationFactory(object):
    """Factory class to build PhFoundation objects from dictionaries.

    Uses the foundation_type_value key in the input dict to determine
    which subclass to instantiate.

    Type Map:
        1-HEATED_BASEMENT: PhHeatedBasement
        2-UNHEATED_BASEMENT: PhUnheatedBasement
        3-SLAB_ON_GRADE: PhSlabOnGrade
        4-VENTED_CRAWLSPACE: PhVentedCrawlspace
        5-NONE: PhFoundation
    """

    type_map = {
        # enum-value: foundation class,
        "1-HEATED_BASEMENT": PhHeatedBasement,
        "2-UNHEATED_BASEMENT": PhUnheatedBasement,
        "3-SLAB_ON_GRADE": PhSlabOnGrade,
        "4-VENTED_CRAWLSPACE": PhVentedCrawlspace,
        "5-NONE": PhFoundation,
    }

    @classmethod
    def _check_input_type_name(cls, _input_type_name):
        # type: (str) -> None
        valid_class_type_names = list(cls.type_map.keys())

        if _input_type_name not in valid_class_type_names:
            msg = 'Error: Unknown PH-Foundation type? Got type of: "{}" but only types: {} are allowed?'.format(
                _input_type_name, valid_class_type_names
            )
            raise Exception(msg)

    @classmethod
    def _get_input_type_name(cls, _input_dict):
        # type: (Dict[str, Any]) -> str
        input_type_enum = PhFoundationType(_input_dict["foundation_type_value"])
        cls._check_input_type_name(input_type_enum.value)
        return input_type_enum.value

    @classmethod
    def from_dict(cls, _input_dict):
        # type: (Dict[str, Any]) -> PhFoundation

        input_type_name = cls._get_input_type_name(_input_dict)
        foundation_class = cls.type_map[input_type_name]
        new_foundation = foundation_class.from_dict(_input_dict)

        return new_foundation
