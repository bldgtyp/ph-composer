# -*- Python Version: 2.7 -*-
# -*- coding: utf-8 -*-

"""HBPH Window Objects"""

try:
    from typing import Any, List
except ImportError:
    pass  # Python 2.7

from honeybee_energy_ph.construction import _base


class PhWindowFrameElement(_base._Base):
    """One side of a PH window frame (top, right, bottom, or left).

    Attributes:
        width (float): Frame element width (m). Default: 0.1.
        u_factor (float): Frame U-value (W/m2K). Default: 1.0.
        psi_glazing (float): Glazing-edge psi-value (W/mK). Default: 0.04.
        psi_install (float): Installation psi-value (W/mK). Default: 0.04.
        chi_value (float): Point thermal bridge chi-value (W/K). Default: 0.0.
        solar_absorptance (float): Exterior-surface solar absorptance of the frame
            (fraction, 0.0-1.0). Used by PHPP's window-frame radiation balance
            (Areas!AI40 -> Windows!O18). Default: 0.25 (PHPP default).
        thermal_emissivity (float): Exterior-surface long-wave thermal emissivity of
            the frame (fraction, 0.0-1.0). Used by PHPP's window-frame radiation balance
            (Areas!AJ40 -> Windows!O19). Default: 0.9 (PHPP default).
    """

    def __init__(self, _identifier):
        super(PhWindowFrameElement, self).__init__(_identifier)
        self.width = 0.1
        self.u_factor = 1.0
        self.psi_glazing = 0.04
        self.psi_install = 0.04
        self.chi_value = 0.0
        self.solar_absorptance = 0.25
        self.thermal_emissivity = 0.9

    def to_dict(self):
        # type: () -> dict[str, Any]
        d = super(PhWindowFrameElement, self).to_dict()
        d["width"] = self.width
        d["u_factor"] = self.u_factor
        d["psi_glazing"] = self.psi_glazing
        d["psi_install"] = self.psi_install
        d["chi_value"] = self.chi_value
        d["solar_absorptance"] = self.solar_absorptance
        d["thermal_emissivity"] = self.thermal_emissivity
        return d

    @classmethod
    def from_dict(cls, _input_dict):
        # type: (dict) -> PhWindowFrameElement
        new_obj = cls(_input_dict["identifier"])
        new_obj.set_base_attrs_from_dict(_input_dict)
        new_obj.width = _input_dict.get("width", new_obj.width)
        new_obj.u_factor = _input_dict.get("u_factor", new_obj.u_factor)
        new_obj.psi_glazing = _input_dict.get("psi_glazing", new_obj.psi_glazing)
        new_obj.psi_install = _input_dict.get("psi_install", new_obj.psi_install)
        new_obj.chi_value = _input_dict.get("chi_value", new_obj.chi_value)
        new_obj.solar_absorptance = _input_dict.get("solar_absorptance", new_obj.solar_absorptance)
        new_obj.thermal_emissivity = _input_dict.get("thermal_emissivity", new_obj.thermal_emissivity)
        return new_obj

    def duplicate(self):
        # type: () -> PhWindowFrameElement
        return self.__copy__()

    def __copy__(self):
        # type: () -> PhWindowFrameElement
        new_obj = self.__class__(self.identifier)
        new_obj.set_base_attrs_from_obj(self)
        new_obj.width = self.width
        new_obj.u_factor = self.u_factor
        new_obj.psi_glazing = self.psi_glazing
        new_obj.psi_install = self.psi_install
        new_obj.chi_value = self.chi_value
        new_obj.solar_absorptance = self.solar_absorptance
        new_obj.thermal_emissivity = self.thermal_emissivity
        return new_obj

    def __str__(self):
        return (
            "{}(width={:.3f}, u_factor={:.3f}, psi_glazing={:.3f}, psi_install={:.3f}, "
            "chi_value={:.3f}, solar_absorptance={:.3f}, thermal_emissivity={:.3f})".format(
                self.__class__.__name__,
                self.width,
                self.u_factor,
                self.psi_glazing,
                self.psi_install,
                self.chi_value,
                self.solar_absorptance,
                self.thermal_emissivity,
            )
        )

    def __repr__(self):
        return str(self)

    def ToString(self):
        return str(self)


class PhWindowFrame(_base._Base):
    """A complete PH window frame with four side elements.

    Attributes:
        top (PhWindowFrameElement): Top frame element.
        right (PhWindowFrameElement): Right frame element.
        bottom (PhWindowFrameElement): Bottom frame element.
        left (PhWindowFrameElement): Left frame element.
    """

    def __init__(self, _identifier):
        super(PhWindowFrame, self).__init__(_identifier)
        self.top = PhWindowFrameElement("PhWindowFrameElement")
        self.right = PhWindowFrameElement("PhWindowFrameElement")
        self.bottom = PhWindowFrameElement("PhWindowFrameElement")
        self.left = PhWindowFrameElement("PhWindowFrameElement")

    @property
    def elements(self):
        # type: () -> List[PhWindowFrameElement]
        """Return all four frame elements in clockwise order from top (t, r, b, l)."""
        return [self.top, self.right, self.bottom, self.left]

    def to_dict(self):
        # type: () -> dict[str, Any]
        d = super(PhWindowFrame, self).to_dict()
        d["top"] = self.top.to_dict()
        d["right"] = self.right.to_dict()
        d["bottom"] = self.bottom.to_dict()
        d["left"] = self.left.to_dict()
        return d

    @classmethod
    def from_dict(cls, _input_dict):
        # type: (dict) -> PhWindowFrame
        new_obj = cls(_input_dict["identifier"])
        new_obj.set_base_attrs_from_dict(_input_dict)
        new_obj.top = PhWindowFrameElement.from_dict(_input_dict["top"])
        new_obj.right = PhWindowFrameElement.from_dict(_input_dict["right"])
        new_obj.bottom = PhWindowFrameElement.from_dict(_input_dict["bottom"])
        new_obj.left = PhWindowFrameElement.from_dict(_input_dict["left"])
        return new_obj

    def duplicate(self):
        # type: () -> PhWindowFrame
        return self.__copy__()

    def __copy__(self):
        # type: () -> PhWindowFrame
        new_obj = self.__class__(self.identifier)
        new_obj.set_base_attrs_from_obj(self)
        new_obj.top = self.top.duplicate()
        new_obj.right = self.right.duplicate()
        new_obj.bottom = self.bottom.duplicate()
        new_obj.left = self.left.duplicate()
        return new_obj

    def __str__(self):
        return "{}(top={!r}, right={!r}, bottom={!r}, left={!r})".format(
            self.__class__.__name__, self.top, self.right, self.bottom, self.left
        )

    def __repr__(self):
        return str(self)

    def ToString(self):
        return str(self)


class PhWindowGlazing(_base._Base):
    """PH-style glazing properties for a window unit.

    Attributes:
        u_factor (float): Center-of-glass U-value (W/m2K). Default: 1.0.
        g_value (float): Solar heat gain coefficient (SHGC). Default: 0.4.
    """

    def __init__(self, _identifier):
        super(PhWindowGlazing, self).__init__(_identifier)
        self.u_factor = 1.0
        self.g_value = 0.4

    def to_dict(self):
        # type: () -> dict[str, Any]
        d = super(PhWindowGlazing, self).to_dict()
        d["u_factor"] = self.u_factor
        d["g_value"] = self.g_value
        return d

    @classmethod
    def from_dict(cls, _input_dict):
        # type: (dict) -> PhWindowGlazing
        new_obj = cls(_input_dict["identifier"])
        new_obj.set_base_attrs_from_dict(_input_dict)
        new_obj.u_factor = _input_dict["u_factor"]
        new_obj.g_value = _input_dict["g_value"]
        return new_obj

    def duplicate(self):
        # type: () -> PhWindowGlazing
        return self.__copy__()

    def __copy__(self):
        # type: () -> PhWindowGlazing
        new_obj = self.__class__(self.identifier)
        new_obj.set_base_attrs_from_obj(self)
        new_obj.u_factor = self.u_factor
        new_obj.g_value = self.g_value
        return new_obj

    def __str__(self):
        return "{}(u_factor={:.3f}, g_value={:.3f})".format(self.__class__.__name__, self.u_factor, self.g_value)

    def __repr__(self):
        return str(self)

    def ToString(self):
        return str(self)


class PhApertureInstallType(_base._Base):
    """A named window-installation condition ('Install Type') with its psi-install value.

    Install conditions (mid-wall, buried jamb, party wall, ...) are properties of where
    a window sits, not of the window construction itself. Instances of this class are
    assigned per-edge on an Aperture's PH properties to override the construction
    frame-element's default 'psi_install' value without duplicating the construction.
    A psi_install of 0.0 is the 'no install thermal bridge' state - there is no
    separate on/off flag.

    Attributes:
        psi_install (float): Installation psi-value (W/mK). Default: 0.0.
        source (str): Optional free-text provenance note (eg. 'Phius mid-wall',
            'Flixo calc 2026-08-01'). Default: "".
    """

    def __init__(self, _identifier):
        super(PhApertureInstallType, self).__init__(_identifier)
        self.psi_install = 0.0
        self.source = ""

    def to_dict(self):
        # type: () -> dict[str, Any]
        d = super(PhApertureInstallType, self).to_dict()
        d["psi_install"] = self.psi_install
        d["source"] = self.source
        return d

    @classmethod
    def from_dict(cls, _input_dict):
        # type: (dict) -> PhApertureInstallType
        new_obj = cls(_input_dict["identifier"])
        new_obj.set_base_attrs_from_dict(_input_dict)
        new_obj.psi_install = _input_dict.get("psi_install", new_obj.psi_install)
        new_obj.source = _input_dict.get("source", new_obj.source)
        return new_obj

    def duplicate(self):
        # type: () -> PhApertureInstallType
        return self.__copy__()

    def __copy__(self):
        # type: () -> PhApertureInstallType
        new_obj = self.__class__(self.identifier)
        new_obj.set_base_attrs_from_obj(self)
        new_obj.psi_install = self.psi_install
        new_obj.source = self.source
        return new_obj

    def __str__(self):
        return "{}(display_name={}, psi_install={:.3f}, source={})".format(
            self.__class__.__name__, self.display_name, self.psi_install, self.source
        )

    def __repr__(self):
        return str(self)

    def ToString(self):
        return str(self)
